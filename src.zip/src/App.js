import logo from './logo.svg';
import './App.css';
import Inicio from './components/Inicio';

function App() {
  return (
    <div className="App">
      <Inicio />
    </div>
  );
}

export default App;
